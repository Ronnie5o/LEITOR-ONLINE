import { storagePut } from "./storage";
import { nanoid } from "nanoid";

export async function uploadBookFile(
  fileBuffer: Buffer,
  fileName: string,
  fileType: "pdf" | "epub"
): Promise<{ url: string; key: string }> {
  // Validate file type
  const validExtensions = {
    pdf: ".pdf",
    epub: ".epub",
  };

  const fileExtension = validExtensions[fileType];
  const sanitizedFileName = fileName.replace(/[^a-zA-Z0-9.-]/g, "_");
  const uniqueFileName = `${nanoid()}-${sanitizedFileName}${fileExtension}`;
  const fileKey = `books/${uniqueFileName}`;

  try {
    const result = await storagePut(fileKey, fileBuffer, `application/${fileType}`);
    return {
      url: result.url,
      key: result.key,
    };
  } catch (error) {
    console.error("Error uploading file to S3:", error);
    throw new Error("Failed to upload file");
  }
}
