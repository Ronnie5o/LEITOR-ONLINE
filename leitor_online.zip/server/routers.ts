import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { uploadBookFile } from "./upload";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  books: router({
    list: publicProcedure.query(() => {
      return db.getAllBooks();
    }),
    search: publicProcedure
      .input(z.object({ query: z.string() }))
      .query(({ input }) => {
        return db.searchBooks(input.query);
      }),
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(({ input }) => {
        return db.getBookById(input.id);
      }),
    create: protectedProcedure
      .input(z.object({
        title: z.string(),
        author: z.string(),
        description: z.string().optional(),
        coverUrl: z.string().optional(),
        fileUrl: z.string(),
        fileType: z.enum(["pdf", "epub"]),
        fileSize: z.number().optional(),
        totalPages: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== "admin") throw new Error("Unauthorized");
        return db.createBook(input);
      }),
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().optional(),
        author: z.string().optional(),
        description: z.string().optional(),
        coverUrl: z.string().optional(),
        totalPages: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== "admin") throw new Error("Unauthorized");
        const { id, ...data } = input;
        return db.updateBook(id, data);
      }),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== "admin") throw new Error("Unauthorized");
        return db.deleteBook(input.id);
      }),
  }),

  reading: router({
    getProgress: protectedProcedure
      .input(z.object({ bookId: z.number() }))
      .query(({ ctx, input }) => {
        return db.getReadingProgress(ctx.user.id, input.bookId);
      }),
    updateProgress: protectedProcedure
      .input(z.object({
        bookId: z.number(),
        currentPage: z.number(),
        totalPages: z.number().optional(),
      }))
      .mutation(({ ctx, input }) => {
        return db.updateReadingProgress(
          ctx.user.id,
          input.bookId,
          input.currentPage,
          input.totalPages
        );
      }),
  }),

  favorites: router({
    list: protectedProcedure.query(({ ctx }) => {
      return db.getUserFavorites(ctx.user.id);
    }),
    toggle: protectedProcedure
      .input(z.object({ bookId: z.number() }))
      .mutation(({ ctx, input }) => {
        return db.toggleFavorite(ctx.user.id, input.bookId);
      }),
  }),

  bookmarks: router({
    list: protectedProcedure
      .input(z.object({ bookId: z.number() }))
      .query(({ ctx, input }) => {
        return db.getBookmarks(ctx.user.id, input.bookId);
      }),
    create: protectedProcedure
      .input(z.object({
        bookId: z.number(),
        page: z.number(),
        note: z.string().optional(),
      }))
      .mutation(({ ctx, input }) => {
        return db.createBookmark(ctx.user.id, input.bookId, input.page, input.note);
      }),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => {
        return db.deleteBookmark(input.id);
      }),
  }),

  upload: router({
    bookFile: protectedProcedure
      .input(z.object({
        fileBuffer: z.instanceof(Buffer),
        fileName: z.string(),
        fileType: z.enum(["pdf", "epub"]),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== "admin") throw new Error("Unauthorized");
        return uploadBookFile(input.fileBuffer, input.fileName, input.fileType);
      }),
  }),
});

export type AppRouter = typeof appRouter;
