import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Loader2, Plus, Edit2, Trash2, BookOpen } from "lucide-react";
import { toast } from "sonner";

export default function Admin() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingBook, setEditingBook] = useState<any>(null);
  const [formData, setFormData] = useState({
    title: "",
    author: "",
    description: "",
    fileUrl: "",
    fileType: "pdf" as "pdf" | "epub",
    totalPages: "",
  });

  // Fetch books
  const { data: books = [], isLoading, refetch } = trpc.books.list.useQuery();

  // Mutations
  const createBookMutation = trpc.books.create.useMutation({
    onSuccess: () => {
      toast.success("Livro adicionado com sucesso!");
      setFormData({ title: "", author: "", description: "", fileUrl: "", fileType: "pdf", totalPages: "" });
      setIsDialogOpen(false);
      refetch();
    },
    onError: (error) => {
      toast.error("Erro ao adicionar livro: " + error.message);
    },
  });

  const updateBookMutation = trpc.books.update.useMutation({
    onSuccess: () => {
      toast.success("Livro atualizado com sucesso!");
      setEditingBook(null);
      setFormData({ title: "", author: "", description: "", fileUrl: "", fileType: "pdf", totalPages: "" });
      setIsDialogOpen(false);
      refetch();
    },
    onError: (error) => {
      toast.error("Erro ao atualizar livro: " + error.message);
    },
  });

  const deleteBookMutation = trpc.books.delete.useMutation({
    onSuccess: () => {
      toast.success("Livro removido com sucesso!");
      refetch();
    },
    onError: (error) => {
      toast.error("Erro ao remover livro: " + error.message);
    },
  });

  // Check admin access
  if (user?.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-sky-50 to-blue-50">
        <Card className="border-red-200 bg-red-50">
          <CardHeader>
            <CardTitle className="text-red-700">Acesso Negado</CardTitle>
          </CardHeader>
          <CardContent className="text-red-600">
            <p>Você não tem permissão para acessar o painel administrativo.</p>
            <Button onClick={() => navigate("/")} className="mt-4">
              Voltar ao Início
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.title || !formData.author || !formData.fileUrl) {
      toast.error("Preencha todos os campos obrigatórios");
      return;
    }

    const bookData = {
      ...formData,
      totalPages: formData.totalPages ? parseInt(formData.totalPages) : undefined,
    };

    if (editingBook) {
      updateBookMutation.mutate({ id: editingBook.id, ...bookData });
    } else {
      createBookMutation.mutate(bookData);
    }
  };

  const handleEdit = (book: any) => {
    setEditingBook(book);
    setFormData({
      title: book.title,
      author: book.author,
      description: book.description || "",
      fileUrl: book.fileUrl,
      fileType: book.fileType,
      totalPages: book.totalPages?.toString() || "",
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (bookId: number) => {
    if (confirm("Tem certeza que deseja remover este livro?")) {
      deleteBookMutation.mutate({ id: bookId });
    }
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setEditingBook(null);
    setFormData({ title: "", author: "", description: "", fileUrl: "", fileType: "pdf", totalPages: "" });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 via-white to-blue-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-sky-400 to-blue-500 text-white shadow-lg">
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <BookOpen className="w-8 h-8" />
              <h1 className="text-4xl font-bold">Painel Administrativo</h1>
            </div>
            <Button
              onClick={() => navigate("/")}
              variant="outline"
              className="bg-white text-sky-600 hover:bg-sky-50"
            >
              Voltar
            </Button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-8">
        {/* Add Book Button */}
        <div className="mb-8 flex gap-3">
          <Button
            onClick={() => navigate("/admin/upload")}
            className="bg-gradient-to-r from-sky-400 to-blue-500 hover:from-sky-500 hover:to-blue-600 text-white"
          >
            <Plus className="w-5 h-5 mr-2" />
            Upload de Livro
          </Button>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button
                onClick={() => {
                  setEditingBook(null);
                  setFormData({ title: "", author: "", description: "", fileUrl: "", fileType: "pdf", totalPages: "" });
                }}
                variant="outline"
                className="border-sky-200 text-sky-600 hover:bg-sky-50"
              >
                <Plus className="w-5 h-5 mr-2" />
                Adicionar Manualmente
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>
                  {editingBook ? "Editar Livro" : "Adicionar Novo Livro"}
                </DialogTitle>
              </DialogHeader>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Título *</label>
                    <Input
                      value={formData.title}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                      placeholder="Título do livro"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Autor *</label>
                    <Input
                      value={formData.author}
                      onChange={(e) => setFormData({ ...formData, author: e.target.value })}
                      placeholder="Nome do autor"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Descrição</label>
                  <textarea
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Descrição do livro"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    rows={3}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">URL do Arquivo *</label>
                    <Input
                      value={formData.fileUrl}
                      onChange={(e) => setFormData({ ...formData, fileUrl: e.target.value })}
                      placeholder="https://..."
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Tipo de Arquivo</label>
                    <select
                      value={formData.fileType}
                      onChange={(e) => setFormData({ ...formData, fileType: e.target.value as "pdf" | "epub" })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    >
                      <option value="pdf">PDF</option>
                      <option value="epub">EPUB</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Total de Páginas</label>
                  <Input
                    type="number"
                    value={formData.totalPages}
                    onChange={(e) => setFormData({ ...formData, totalPages: e.target.value })}
                    placeholder="0"
                  />
                </div>

                <div className="flex gap-2 justify-end">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleCloseDialog}
                  >
                    Cancelar
                  </Button>
                  <Button
                    type="submit"
                    disabled={createBookMutation.isPending || updateBookMutation.isPending}
                    className="bg-sky-500 hover:bg-sky-600"
                  >
                    {createBookMutation.isPending || updateBookMutation.isPending ? (
                      <Loader2 className="w-4 h-4 animate-spin mr-2" />
                    ) : null}
                    {editingBook ? "Atualizar" : "Adicionar"}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Books Table */}
        <Card className="border-sky-100">
          <CardHeader>
            <CardTitle>Livros na Biblioteca ({books.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="w-8 h-8 animate-spin text-sky-400" />
              </div>
            ) : books.length === 0 ? (
              <p className="text-center text-gray-500 py-8">Nenhum livro adicionado ainda</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200">
                      <th className="text-left py-3 px-4 font-semibold">Título</th>
                      <th className="text-left py-3 px-4 font-semibold">Autor</th>
                      <th className="text-left py-3 px-4 font-semibold">Tipo</th>
                      <th className="text-left py-3 px-4 font-semibold">Páginas</th>
                      <th className="text-right py-3 px-4 font-semibold">Ações</th>
                    </tr>
                  </thead>
                  <tbody>
                    {books.map((book) => (
                      <tr key={book.id} className="border-b border-gray-100 hover:bg-sky-50">
                        <td className="py-3 px-4">{book.title}</td>
                        <td className="py-3 px-4">{book.author}</td>
                        <td className="py-3 px-4">
                          <Badge variant="secondary" className="bg-sky-100 text-sky-700">
                            {book.fileType.toUpperCase()}
                          </Badge>
                        </td>
                        <td className="py-3 px-4">{book.totalPages || "-"}</td>
                        <td className="py-3 px-4 text-right">
                          <div className="flex gap-2 justify-end">
                            <Button
                              onClick={() => handleEdit(book)}
                              variant="outline"
                              size="sm"
                              className="border-sky-200 text-sky-600 hover:bg-sky-50"
                            >
                              <Edit2 className="w-4 h-4" />
                            </Button>
                            <Button
                              onClick={() => handleDelete(book.id)}
                              variant="outline"
                              size="sm"
                              className="border-red-200 text-red-600 hover:bg-red-50"
                              disabled={deleteBookMutation.isPending}
                            >
                              {deleteBookMutation.isPending ? (
                                <Loader2 className="w-4 h-4 animate-spin" />
                              ) : (
                                <Trash2 className="w-4 h-4" />
                              )}
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
