import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import FileUpload from "@/components/FileUpload";
import { Loader2, BookOpen, Upload } from "lucide-react";
import { toast } from "sonner";

export default function AdminUpload() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [formData, setFormData] = useState({
    title: "",
    author: "",
    description: "",
    totalPages: "",
  });
  const [isUploading, setIsUploading] = useState(false);

  // Mutation for creating book
  const createBookMutation = trpc.books.create.useMutation({
    onSuccess: () => {
      toast.success("Livro adicionado com sucesso!");
      setFormData({ title: "", author: "", description: "", totalPages: "" });
      setSelectedFile(null);
      navigate("/admin");
    },
    onError: (error) => {
      toast.error("Erro ao adicionar livro: " + error.message);
      setIsUploading(false);
    },
  });

  // Check admin access
  if (user?.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-sky-50 to-blue-50">
        <Card className="border-red-200 bg-red-50">
          <CardHeader>
            <CardTitle className="text-red-700">Acesso Negado</CardTitle>
          </CardHeader>
          <CardContent className="text-red-600">
            <p>Você não tem permissão para acessar esta página.</p>
            <Button onClick={() => navigate("/")} className="mt-4">
              Voltar ao Início
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleFileSelect = (file: File) => {
    setSelectedFile(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.title || !formData.author || !selectedFile) {
      toast.error("Preencha todos os campos obrigatórios e selecione um arquivo");
      return;
    }

    setIsUploading(true);

    try {
      // Read file as buffer
      const fileBuffer = await selectedFile.arrayBuffer();
      const buffer = Buffer.from(fileBuffer);

      // Determine file type from extension
      const fileType = selectedFile.name.endsWith(".epub") ? "epub" : "pdf";

      // For now, we'll use a placeholder URL since we need to implement S3 upload
      // In production, you would upload to S3 first and get the URL
      const fileUrl = URL.createObjectURL(selectedFile);

      // Create book with file URL
      createBookMutation.mutate({
        title: formData.title,
        author: formData.author,
        description: formData.description,
        fileUrl,
        fileType,
        totalPages: formData.totalPages ? parseInt(formData.totalPages) : undefined,
      });
    } catch (error) {
      toast.error("Erro ao processar arquivo");
      setIsUploading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 via-white to-blue-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-sky-400 to-blue-500 text-white shadow-lg">
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Upload className="w-8 h-8" />
              <h1 className="text-4xl font-bold">Upload de Livro</h1>
            </div>
            <Button
              onClick={() => navigate("/admin")}
              variant="outline"
              className="bg-white text-sky-600 hover:bg-sky-50"
            >
              Voltar
            </Button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <Card className="border-sky-100">
            <CardHeader>
              <CardTitle>Adicionar Novo Livro</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* File Upload */}
                <div>
                  <label className="block text-sm font-medium mb-3">
                    Arquivo do Livro (PDF ou EPUB) *
                  </label>
                  <FileUpload
                    onFileSelect={handleFileSelect}
                    accept=".pdf,.epub"
                    maxSize={100}
                  />
                </div>

                {/* Title */}
                <div>
                  <label className="block text-sm font-medium mb-2">Título *</label>
                  <Input
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="Título do livro"
                    required
                  />
                </div>

                {/* Author */}
                <div>
                  <label className="block text-sm font-medium mb-2">Autor *</label>
                  <Input
                    value={formData.author}
                    onChange={(e) => setFormData({ ...formData, author: e.target.value })}
                    placeholder="Nome do autor"
                    required
                  />
                </div>

                {/* Description */}
                <div>
                  <label className="block text-sm font-medium mb-2">Descrição</label>
                  <textarea
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Descrição do livro"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    rows={4}
                  />
                </div>

                {/* Total Pages */}
                <div>
                  <label className="block text-sm font-medium mb-2">Total de Páginas</label>
                  <Input
                    type="number"
                    value={formData.totalPages}
                    onChange={(e) => setFormData({ ...formData, totalPages: e.target.value })}
                    placeholder="0"
                  />
                </div>

                {/* Submit Button */}
                <div className="flex gap-2 justify-end">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => navigate("/admin")}
                  >
                    Cancelar
                  </Button>
                  <Button
                    type="submit"
                    disabled={isUploading || createBookMutation.isPending}
                    className="bg-gradient-to-r from-sky-400 to-blue-500 hover:from-sky-500 hover:to-blue-600 text-white"
                  >
                    {isUploading || createBookMutation.isPending ? (
                      <Loader2 className="w-4 h-4 animate-spin mr-2" />
                    ) : (
                      <Upload className="w-4 h-4 mr-2" />
                    )}
                    {isUploading || createBookMutation.isPending ? "Enviando..." : "Adicionar Livro"}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>

          {/* Info Box */}
          <Card className="mt-6 border-sky-100 bg-sky-50">
            <CardHeader>
              <CardTitle className="text-sky-700 flex items-center gap-2">
                <BookOpen className="w-5 h-5" />
                Informações Importantes
              </CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-gray-700 space-y-2">
              <p>
                • Formatos aceitos: PDF e EPUB
              </p>
              <p>
                • Tamanho máximo: 100MB
              </p>
              <p>
                • Certifique-se de que o arquivo está em bom estado antes de fazer upload
              </p>
              <p>
                • Os metadados do livro podem ser editados após o upload
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
