import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, BookOpen, Heart, LogOut } from "lucide-react";

export default function Dashboard() {
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();

  // Fetch favorites
  const { data: favorites = [], isLoading: favoritesLoading } = trpc.favorites.list.useQuery();

  const handleLogout = async () => {
    await logout();
    navigate("/");
  };

  const favoriteBooks = favorites.map(fav => {
    if (Array.isArray(fav) && fav.length > 1) {
      return fav[0]; // Return the book object
    }
    return null;
  }).filter(Boolean);

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 via-white to-blue-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-sky-400 to-blue-500 text-white shadow-lg">
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold">Meu Dashboard</h1>
              <p className="text-sky-100 mt-2">Bem-vindo, {user?.name}!</p>
            </div>
            <div className="flex gap-2">
              {user?.role === "admin" && (
                <Button
                  onClick={() => navigate("/admin")}
                  variant="outline"
                  className="bg-white text-sky-600 hover:bg-sky-50"
                >
                  Painel Admin
                </Button>
              )}
              <Button
                onClick={handleLogout}
                variant="outline"
                className="bg-white text-sky-600 hover:bg-sky-50"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Sair
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Quick Actions */}
            <Card className="border-sky-100 bg-gradient-to-br from-sky-50 to-blue-50">
              <CardHeader>
                <CardTitle>Ações Rápidas</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button
                  onClick={() => navigate("/library")}
                  className="w-full bg-gradient-to-r from-sky-400 to-blue-500 hover:from-sky-500 hover:to-blue-600 text-white py-6"
                >
                  <BookOpen className="w-5 h-5 mr-2" />
                  Explorar Biblioteca
                </Button>
              </CardContent>
            </Card>

            {/* Favorites */}
            <Card className="border-sky-100">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Heart className="w-5 h-5 text-red-500" />
                  Meus Favoritos ({favoriteBooks.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                {favoritesLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="w-8 h-8 animate-spin text-sky-400" />
                  </div>
                ) : favoriteBooks.length === 0 ? (
                  <p className="text-center text-gray-500 py-8">
                    Você ainda não marcou nenhum livro como favorito
                  </p>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {favoriteBooks.map((book: any) => (
                      <Card
                        key={book.id}
                        className="cursor-pointer hover:shadow-lg transition-all border-sky-100 hover:border-sky-300"
                        onClick={() => navigate(`/reader/${book.id}`)}
                      >
                        <CardHeader className="pb-3">
                          <CardTitle className="text-lg line-clamp-2">
                            {book.title}
                          </CardTitle>
                          <p className="text-sm text-gray-600">por {book.author}</p>
                        </CardHeader>
                        <CardContent>
                          <Button
                            className="w-full bg-sky-500 hover:bg-sky-600 text-white"
                            onClick={(e) => {
                              e.stopPropagation();
                              navigate(`/reader/${book.id}`);
                            }}
                          >
                            Continuar Lendo
                          </Button>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-4">
            {/* Profile Info */}
            <Card className="border-sky-100">
              <CardHeader>
                <CardTitle>Informações da Conta</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <p className="text-sm text-gray-600">Nome</p>
                  <p className="font-semibold">{user?.name}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Email</p>
                  <p className="font-semibold">{user?.email}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Função</p>
                  <Badge className={user?.role === "admin" ? "bg-sky-500" : "bg-gray-500"}>
                    {user?.role === "admin" ? "Administrador" : "Usuário"}
                  </Badge>
                </div>
              </CardContent>
            </Card>

            {/* Stats */}
            <Card className="border-sky-100">
              <CardHeader>
                <CardTitle>Estatísticas</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="text-center p-3 bg-sky-50 rounded-lg">
                  <p className="text-3xl font-bold text-sky-600">{favoriteBooks.length}</p>
                  <p className="text-sm text-gray-600">Livros Favoritos</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
