import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, Search, BookOpen, Heart } from "lucide-react";
import { useLocation } from "wouter";

export default function Library() {
  const [searchQuery, setSearchQuery] = useState("");
  const [, navigate] = useLocation();
  
  const { data: books = [], isLoading } = trpc.books.list.useQuery();
  const { data: favorites = [] } = trpc.favorites.list.useQuery();

  const filteredBooks = useMemo(() => {
    if (!searchQuery) return books;
    return books.filter(book =>
      book.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      book.author.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [books, searchQuery]);

  const favoriteBookIds = new Set(favorites.map(fav => {
    if (Array.isArray(fav) && fav.length > 1) {
      return fav[1].bookId;
    }
    return null;
  }).filter(Boolean));

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 via-white to-blue-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-sky-400 to-blue-500 text-white shadow-lg">
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center gap-3 mb-6">
            <BookOpen className="w-8 h-8" />
            <h1 className="text-4xl font-bold">Biblioteca Digital</h1>
          </div>
          <p className="text-sky-100 text-lg">Explore milhares de livros para ler online</p>
        </div>
      </div>

      {/* Search Section */}
      <div className="container mx-auto px-4 py-8">
        <div className="relative mb-8">
          <Search className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
          <Input
            placeholder="Buscar por título ou autor..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 py-6 text-lg border-2 border-sky-200 focus:border-sky-400 rounded-lg"
          />
        </div>

        {/* Results Info */}
        <div className="mb-6 flex items-center justify-between">
          <p className="text-gray-600 font-medium">
            {filteredBooks.length} livro{filteredBooks.length !== 1 ? "s" : ""} encontrado{filteredBooks.length !== 1 ? "s" : ""}
          </p>
        </div>

        {/* Books Grid */}
        {isLoading ? (
          <div className="flex justify-center items-center py-16">
            <Loader2 className="w-8 h-8 animate-spin text-sky-400" />
          </div>
        ) : filteredBooks.length === 0 ? (
          <div className="text-center py-16">
            <BookOpen className="w-16 h-16 mx-auto text-gray-300 mb-4" />
            <p className="text-gray-500 text-lg">Nenhum livro encontrado</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredBooks.map((book) => (
              <Card
                key={book.id}
                className="hover:shadow-xl transition-all duration-300 cursor-pointer border-sky-100 hover:border-sky-300 overflow-hidden group"
                onClick={() => navigate(`/reader/${book.id}`)}
              >
                {/* Cover Image */}
                <div className="relative h-48 bg-gradient-to-br from-sky-200 to-blue-300 overflow-hidden">
                  {book.coverUrl ? (
                    <img
                      src={book.coverUrl}
                      alt={book.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <BookOpen className="w-12 h-12 text-sky-400 opacity-50" />
                    </div>
                  )}
                </div>

                {/* Content */}
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1">
                      <CardTitle className="text-lg line-clamp-2 text-gray-800">
                        {book.title}
                      </CardTitle>
                      <CardDescription className="text-sm text-gray-600 mt-1">
                        por {book.author}
                      </CardDescription>
                    </div>
                    {favoriteBookIds.has(book.id) && (
                      <Heart className="w-5 h-5 fill-red-500 text-red-500 flex-shrink-0" />
                    )}
                  </div>
                </CardHeader>

                <CardContent className="space-y-3">
                  {book.description && (
                    <p className="text-sm text-gray-600 line-clamp-2">
                      {book.description}
                    </p>
                  )}
                  
                  <div className="flex gap-2 flex-wrap">
                    {book.totalPages && (
                      <Badge variant="secondary" className="bg-sky-100 text-sky-700">
                        {book.totalPages} páginas
                      </Badge>
                    )}
                    <Badge variant="outline" className="text-sky-600 border-sky-200">
                      {book.fileType.toUpperCase()}
                    </Badge>
                  </div>

                  <Button
                    className="w-full bg-gradient-to-r from-sky-400 to-blue-500 hover:from-sky-500 hover:to-blue-600 text-white font-semibold py-2 rounded-lg transition-all"
                    onClick={(e) => {
                      e.stopPropagation();
                      navigate(`/reader/${book.id}`);
                    }}
                  >
                    Ler Agora
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
