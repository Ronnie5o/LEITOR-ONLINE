import { useState, useEffect, useRef } from "react";
import { useRoute, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import {
  ChevronLeft,
  ChevronRight,
  ZoomIn,
  ZoomOut,
  Bookmark,
  Heart,
  Menu,
  X,
  Loader2,
} from "lucide-react";
import * as pdfjsLib from "pdfjs-dist";

// Set up PDF.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`;

export default function Reader() {
  const [, params] = useRoute("/reader/:id");
  const [, navigate] = useLocation();
  const bookId = params?.id ? parseInt(params.id) : null;

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(0);
  const [zoom, setZoom] = useState(100);
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [isFavorite, setIsFavorite] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [pdfDoc, setPdfDoc] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Fetch book data
  const { data: book, isLoading: bookLoading } = trpc.books.getById.useQuery(
    { id: bookId || 0 },
    { enabled: !!bookId }
  );

  // Fetch reading progress
  const { data: progress } = trpc.reading.getProgress.useQuery(
    { bookId: bookId || 0 },
    { enabled: !!bookId }
  );

  // Fetch bookmarks
  const { data: bookmarks = [] } = trpc.bookmarks.list.useQuery(
    { bookId: bookId || 0 },
    { enabled: !!bookId }
  );

  // Mutations
  const updateProgressMutation = trpc.reading.updateProgress.useMutation();
  const toggleFavoriteMutation = trpc.favorites.toggle.useMutation();
  const createBookmarkMutation = trpc.bookmarks.create.useMutation();

  // Load PDF
  useEffect(() => {
    if (!book) return;

    const loadPdf = async () => {
      try {
        setIsLoading(true);
        const pdf = await pdfjsLib.getDocument(book.fileUrl).promise;
        setPdfDoc(pdf);
        setTotalPages(pdf.numPages);

        // Set current page from progress
        if (progress?.currentPage) {
          setCurrentPage(progress.currentPage);
        } else {
          setCurrentPage(1);
        }
      } catch (error) {
        console.error("Error loading PDF:", error);
      } finally {
        setIsLoading(false);
      }
    };

    loadPdf();
  }, [book, progress]);

  // Render PDF page
  useEffect(() => {
    if (!pdfDoc || !canvasRef.current) return;

    const renderPage = async () => {
      try {
        const page = await pdfDoc.getPage(currentPage);
        const scale = zoom / 100;
        const viewport = page.getViewport({ scale });

        const canvas = canvasRef.current;
        if (!canvas) return;
        const context = canvas.getContext("2d");
        if (!context) return;

        canvas.width = viewport.width;
        canvas.height = viewport.height;

        await page.render({
          canvasContext: context,
          viewport: viewport,
        }).promise;
      } catch (error) {
        console.error("Error rendering page:", error);
      }
    };

    renderPage();
  }, [pdfDoc, currentPage, zoom]);

  // Update progress
  useEffect(() => {
    if (!bookId || !totalPages) return;

    const timer = setTimeout(() => {
      updateProgressMutation.mutate({
        bookId,
        currentPage,
        totalPages,
      });
    }, 1000);

    return () => clearTimeout(timer);
  }, [currentPage, bookId, totalPages]);

  // Check if current page is bookmarked
  useEffect(() => {
    setIsBookmarked(bookmarks.some(bm => bm.page === currentPage));
  }, [bookmarks, currentPage]);

  const handlePreviousPage = () => {
    setCurrentPage(prev => Math.max(1, prev - 1));
  };

  const handleNextPage = () => {
    setCurrentPage(prev => Math.min(totalPages, prev + 1));
  };

  const handleZoomIn = () => {
    setZoom(prev => Math.min(200, prev + 10));
  };

  const handleZoomOut = () => {
    setZoom(prev => Math.max(50, prev - 10));
  };

  const handleToggleBookmark = () => {
    if (!bookId) return;
    createBookmarkMutation.mutate({
      bookId,
      page: currentPage,
      note: "",
    });
  };

  const handleToggleFavorite = () => {
    if (!bookId) return;
    toggleFavoriteMutation.mutate({ bookId });
    setIsFavorite(!isFavorite);
  };

  if (bookLoading || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-900">
        <Loader2 className="w-8 h-8 animate-spin text-sky-400" />
      </div>
    );
  }

  if (!book) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-900">
        <div className="text-center">
          <p className="text-white text-lg mb-4">Livro não encontrado</p>
          <Button onClick={() => navigate("/library")}>Voltar à Biblioteca</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Header */}
      <div className="bg-gray-800 border-b border-gray-700 p-4">
        <div className="container mx-auto flex items-center justify-between">
          <div className="flex-1">
            <h1 className="text-2xl font-bold">{book.title}</h1>
            <p className="text-gray-400">{book.author}</p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setShowMenu(!showMenu)}
            className="text-white hover:bg-gray-700"
          >
            {showMenu ? <X /> : <Menu />}
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto py-8 flex gap-8">
        {/* Reader */}
        <div className="flex-1">
          <div className="bg-gray-800 rounded-lg p-4 mb-4">
            <div className="flex items-center justify-center bg-gray-900 rounded mb-4 overflow-auto max-h-96">
              <canvas ref={canvasRef} className="max-w-full" />
            </div>

            {/* Controls */}
            <div className="space-y-4">
              {/* Page Navigation */}
              <div className="flex items-center justify-between gap-4">
                <Button
                  onClick={handlePreviousPage}
                  disabled={currentPage === 1}
                  className="bg-sky-500 hover:bg-sky-600"
                >
                  <ChevronLeft className="w-5 h-5" />
                </Button>

                <div className="flex-1">
                  <Slider
                    value={[currentPage]}
                    onValueChange={(value) => setCurrentPage(value[0])}
                    min={1}
                    max={totalPages}
                    step={1}
                    className="w-full"
                  />
                </div>

                <Button
                  onClick={handleNextPage}
                  disabled={currentPage === totalPages}
                  className="bg-sky-500 hover:bg-sky-600"
                >
                  <ChevronRight className="w-5 h-5" />
                </Button>
              </div>

              {/* Page Info */}
              <div className="text-center text-gray-400">
                Página {currentPage} de {totalPages}
              </div>

              {/* Zoom Controls */}
              <div className="flex items-center justify-center gap-4">
                <Button
                  onClick={handleZoomOut}
                  variant="outline"
                  size="icon"
                  className="border-gray-600 text-white hover:bg-gray-700"
                >
                  <ZoomOut className="w-5 h-5" />
                </Button>
                <span className="w-12 text-center">{zoom}%</span>
                <Button
                  onClick={handleZoomIn}
                  variant="outline"
                  size="icon"
                  className="border-gray-600 text-white hover:bg-gray-700"
                >
                  <ZoomIn className="w-5 h-5" />
                </Button>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-2">
                <Button
                  onClick={handleToggleBookmark}
                  variant={isBookmarked ? "default" : "outline"}
                  className={isBookmarked ? "bg-sky-500 hover:bg-sky-600" : "border-gray-600 text-white hover:bg-gray-700"}
                >
                  <Bookmark className="w-5 h-5 mr-2" />
                  Marcador
                </Button>
                <Button
                  onClick={handleToggleFavorite}
                  variant={isFavorite ? "default" : "outline"}
                  className={isFavorite ? "bg-red-500 hover:bg-red-600" : "border-gray-600 text-white hover:bg-gray-700"}
                >
                  <Heart className="w-5 h-5 mr-2" />
                  Favorito
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        {showMenu && (
          <div className="w-64 space-y-4">
            {/* Book Info */}
            <Card className="bg-gray-800 border-gray-700 p-4">
              <h3 className="font-bold mb-2">Informações</h3>
              <div className="space-y-2 text-sm text-gray-400">
                <p><strong>Páginas:</strong> {totalPages}</p>
                <p><strong>Tipo:</strong> {book.fileType.toUpperCase()}</p>
                {progress && (
                  <p><strong>Progresso:</strong> {progress.percentageRead}%</p>
                )}
              </div>
            </Card>

            {/* Bookmarks */}
            {bookmarks.length > 0 && (
              <Card className="bg-gray-800 border-gray-700 p-4">
                <h3 className="font-bold mb-2">Marcadores</h3>
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {bookmarks.map((bm) => (
                    <div
                      key={bm.id}
                      onClick={() => setCurrentPage(bm.page)}
                      className="p-2 bg-gray-700 rounded cursor-pointer hover:bg-gray-600 text-sm"
                    >
                      <p className="font-semibold">Página {bm.page}</p>
                      {bm.note && <p className="text-gray-400">{bm.note}</p>}
                    </div>
                  ))}
                </div>
              </Card>
            )}

            {/* Back Button */}
            <Button
              onClick={() => navigate("/library")}
              variant="outline"
              className="w-full border-gray-600 text-white hover:bg-gray-700"
            >
              Voltar à Biblioteca
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
