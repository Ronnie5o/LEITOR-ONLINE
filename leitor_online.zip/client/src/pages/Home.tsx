import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { BookOpen, Zap, Users, Shield } from "lucide-react";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-sky-50 to-blue-50">
        <div className="animate-spin">
          <BookOpen className="w-12 h-12 text-sky-400" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 via-white to-blue-50">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b border-sky-100">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BookOpen className="w-8 h-8 text-sky-500" />
            <span className="text-2xl font-bold text-gray-800">Leitor Online</span>
          </div>
          <div className="flex items-center gap-4">
            {isAuthenticated ? (
              <>
                <span className="text-gray-600">Bem-vindo, {user?.name}</span>
                <Button
                  onClick={() => navigate("/library")}
                  className="bg-sky-500 hover:bg-sky-600 text-white"
                >
                  Biblioteca
                </Button>
              </>
            ) : (
              <a href={getLoginUrl()}>
                <Button className="bg-sky-500 hover:bg-sky-600 text-white">
                  Entrar
                </Button>
              </a>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8">
            <div>
              <h1 className="text-5xl lg:text-6xl font-bold text-gray-900 mb-4">
                Sua Biblioteca Digital
              </h1>
              <p className="text-xl text-gray-600 leading-relaxed">
                Leia seus livros favoritos em qualquer lugar, a qualquer hora. Uma experiência de leitura moderna e intuitiva.
              </p>
            </div>

            <div className="space-y-4">
              {isAuthenticated ? (
                <Button
                  onClick={() => navigate("/library")}
                  size="lg"
                  className="bg-gradient-to-r from-sky-400 to-blue-500 hover:from-sky-500 hover:to-blue-600 text-white text-lg px-8 py-6 rounded-lg"
                >
                  Explorar Biblioteca
                </Button>
              ) : (
                <a href={getLoginUrl()}>
                  <Button
                    size="lg"
                    className="bg-gradient-to-r from-sky-400 to-blue-500 hover:from-sky-500 hover:to-blue-600 text-white text-lg px-8 py-6 rounded-lg w-full"
                  >
                    Começar Agora
                  </Button>
                </a>
              )}
            </div>
          </div>

          {/* Right Visual */}
          <div className="relative">
            <div className="bg-gradient-to-br from-sky-200 to-blue-300 rounded-2xl p-8 shadow-2xl">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white rounded-lg p-4 shadow-md transform -rotate-3 hover:rotate-0 transition-transform">
                  <BookOpen className="w-8 h-8 text-sky-500 mb-2" />
                  <p className="text-sm font-semibold text-gray-800">Leitura Fluida</p>
                </div>
                <div className="bg-white rounded-lg p-4 shadow-md transform rotate-3 hover:rotate-0 transition-transform">
                  <Zap className="w-8 h-8 text-blue-500 mb-2" />
                  <p className="text-sm font-semibold text-gray-800">Rápida</p>
                </div>
                <div className="bg-white rounded-lg p-4 shadow-md transform -rotate-3 hover:rotate-0 transition-transform">
                  <Users className="w-8 h-8 text-sky-500 mb-2" />
                  <p className="text-sm font-semibold text-gray-800">Social</p>
                </div>
                <div className="bg-white rounded-lg p-4 shadow-md transform rotate-3 hover:rotate-0 transition-transform">
                  <Shield className="w-8 h-8 text-blue-500 mb-2" />
                  <p className="text-sm font-semibold text-gray-800">Segura</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-white py-20 border-t border-sky-100">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center text-gray-900 mb-16">
            Recursos Principais
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="text-center space-y-4">
              <div className="bg-sky-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto">
                <BookOpen className="w-8 h-8 text-sky-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900">Biblioteca Completa</h3>
              <p className="text-gray-600">
                Acesso a uma vasta coleção de livros em PDF e EPUB
              </p>
            </div>

            {/* Feature 2 */}
            <div className="text-center space-y-4">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto">
                <Zap className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900">Leitor Inteligente</h3>
              <p className="text-gray-600">
                Controle de fonte, marcadores e progresso de leitura
              </p>
            </div>

            {/* Feature 3 */}
            <div className="text-center space-y-4">
              <div className="bg-sky-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto">
                <Heart className="w-8 h-8 text-sky-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900">Seus Favoritos</h3>
              <p className="text-gray-600">
                Marque seus livros preferidos e organize sua leitura
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="container mx-auto px-4 text-center">
          <p className="text-gray-400">
            © 2024 Leitor Online. Todos os direitos reservados.
          </p>
        </div>
      </footer>
    </div>
  );
}

import { Heart } from "lucide-react";
